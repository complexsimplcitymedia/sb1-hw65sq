import React, { useState, useEffect, useRef } from 'react';
import { RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { convaiService } from '../lib/convai';
import { webRTCManager } from '../lib/webrtc';
import VoiceIndicator from './PixelStream/VoiceIndicator';
import StreamControls from './PixelStream/StreamControls';
import MobileTouchButton from './PixelStream/MobileTouchButton';

interface PixelStreamViewerProps {
  streamUrl: string;
  width?: string | number;
  height?: string | number;
}

export default function PixelStreamViewer({ 
  streamUrl,
  width = '100%', 
  height = '100%' 
}: PixelStreamViewerProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isKeyPressed, setIsKeyPressed] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isStreamReady, setIsStreamReady] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      iframeRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const retryConnection = () => {
    if (iframeRef.current) {
      setIsStreamReady(false);
      setError(null);
      iframeRef.current.src = streamUrl;
    }
  };

  const handleTouchStart = async () => {
    if (!isKeyPressed && isStreamReady) {
      try {
        await convaiService.startAudioInput();
        await webRTCManager.startAudio();
        setIsKeyPressed(true);
        
        if (iframeRef.current?.contentWindow) {
          const message = {
            type: 'keyEvent',
            eventType: 'keydown',
            key: 'T',
            code: 'KeyT',
            keyCode: 84
          };
          
          iframeRef.current.contentWindow.postMessage(message, new URL(streamUrl).origin);
        }
      } catch (error) {
        console.error('Failed to start audio capture:', error);
        setError('Failed to access microphone');
      }
    }
  };

  const handleTouchEnd = async () => {
    if (isKeyPressed && isStreamReady) {
      try {
        await convaiService.stopAudioInput();
        webRTCManager.stopAudio();
        setIsKeyPressed(false);
        
        if (iframeRef.current?.contentWindow) {
          const message = {
            type: 'keyEvent',
            eventType: 'keyup',
            key: 'T',
            code: 'KeyT',
            keyCode: 84
          };
          
          iframeRef.current.contentWindow.postMessage(message, new URL(streamUrl).origin);
        }
      } catch (error) {
        console.error('Failed to stop audio capture:', error);
      }
    }
  };

  useEffect(() => {
    if (!window.isSecureContext) {
      setError('Voice functionality requires a secure HTTPS connection');
      return;
    }

    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    const handleMessage = (event: MessageEvent) => {
      const streamOrigin = new URL(streamUrl).origin;
      if (event.origin !== streamOrigin) return;

      if (event.data.type === 'streamReady') {
        setIsStreamReady(true);
        iframeRef.current?.focus();
      } else if (event.data.type === 'streamError') {
        setError('Stream connection lost. Please try refreshing.');
        setIsStreamReady(false);
      }
    };

    const handleKeyDown = async (event: KeyboardEvent) => {
      if (event.code === 'KeyT' && !isKeyPressed && document.activeElement === iframeRef.current && isStreamReady) {
        try {
          await convaiService.startAudioInput();
          await webRTCManager.startAudio();
          setIsKeyPressed(true);
          
          if (iframeRef.current?.contentWindow) {
            const message = {
              type: 'keyEvent',
              eventType: 'keydown',
              key: 'T',
              code: 'KeyT',
              keyCode: 84
            };
            
            iframeRef.current.contentWindow.postMessage(message, new URL(streamUrl).origin);
          }
        } catch (error) {
          console.error('Failed to start audio capture:', error);
          setError('Failed to access microphone');
        }
      }
    };

    const handleKeyUp = async (event: KeyboardEvent) => {
      if (event.code === 'KeyT' && isKeyPressed && document.activeElement === iframeRef.current && isStreamReady) {
        try {
          await convaiService.stopAudioInput();
          webRTCManager.stopAudio();
          setIsKeyPressed(false);
          
          if (iframeRef.current?.contentWindow) {
            const message = {
              type: 'keyEvent',
              eventType: 'keyup',
              key: 'T',
              code: 'KeyT',
              keyCode: 84
            };
            
            iframeRef.current.contentWindow.postMessage(message, new URL(streamUrl).origin);
          }
        } catch (error) {
          console.error('Failed to stop audio capture:', error);
        }
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    window.addEventListener('message', handleMessage);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      window.removeEventListener('message', handleMessage);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('keyup', handleKeyUp);
      webRTCManager.cleanup();
    };
  }, [streamUrl, isKeyPressed, isStreamReady]);

  if (error) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-black rounded-xl">
        <div className="text-center text-white p-6">
          <p className="text-red-400 mb-4">{error}</p>
          <button
            onClick={retryConnection}
            className="px-4 py-2 bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
          >
            <RefreshCw className="w-5 h-5" />
            <span>Retry Connection</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full rounded-xl overflow-hidden bg-black">
      <iframe
        ref={iframeRef}
        src={streamUrl}
        className="w-full h-full border-0"
        style={{ width, height }}
        allow="microphone; camera; fullscreen; autoplay; clipboard-read; clipboard-write"
        allowFullScreen
        sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-downloads allow-modals"
        referrerPolicy="strict-origin-when-cross-origin"
        loading="eager"
        importance="high"
        fetchpriority="high"
        tabIndex={0}
      />

      <div className="absolute bottom-4 right-4 z-[9999] flex items-center space-x-4">
        <AnimatePresence>
          {isKeyPressed && <VoiceIndicator isRecording={isKeyPressed} />}
        </AnimatePresence>
        <StreamControls 
          isFullscreen={isFullscreen} 
          onToggleFullscreen={toggleFullscreen} 
        />
      </div>

      {isMobile && (
        <MobileTouchButton
          isPressed={isKeyPressed}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        />
      )}
    </div>
  );
}